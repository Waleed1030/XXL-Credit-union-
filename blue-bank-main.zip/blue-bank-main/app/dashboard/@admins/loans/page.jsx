import React from 'react'

const Loans = () => {
  return (
    <div className='w-full h-[400px] flex justify-center items-center'>Still under Construction . . . </div>
  )
}

export default Loans