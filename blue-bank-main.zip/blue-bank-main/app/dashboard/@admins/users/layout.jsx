import React from 'react'
import { Suspense } from 'react'

const layout = ({children}) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default layout