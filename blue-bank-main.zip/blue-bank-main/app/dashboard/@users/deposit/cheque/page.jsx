import React from 'react'

const ChequeDeposit = () => {
  return (
    <div>ChequeDeposit</div>
  )
}

export default ChequeDeposit