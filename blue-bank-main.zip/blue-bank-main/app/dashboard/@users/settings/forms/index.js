import  GeneralInfo  from './general'
import  ChangePin  from './pin'
import  ChangePassword  from './password'


export {
    GeneralInfo,
    ChangePin,
    ChangePassword,
}