const Public = ({children}) => {
    return (
      <div>
          {children}
      </div>
    )
  }
  
  export default Public