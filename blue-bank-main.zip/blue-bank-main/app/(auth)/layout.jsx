const Auth = ({children}) => {
    return (
      <div>
          {children}
      </div>
    )
  }
  
  export default Auth