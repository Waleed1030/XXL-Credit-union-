import React from 'react'
import './loading.css'

const LoadingBtn = () => {
  return (
    <div className='button-loading'></div>
  )
}

export default LoadingBtn