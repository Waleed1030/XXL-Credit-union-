import React from 'react'

const Suspended = () => {
  return (
    <div>Suspended</div>
  )
}

export default Suspended