"use client"
import { HiX } from "react-icons/hi";
import { motion } from "framer-motion";
import  Link  from "next/navigation";
import { FaCheckCircle } from "react-icons/fa";

const page = () => {
  return (
          <div className="flex justify-center items-center gap-3 mt-10 w-full">
            <button className="primary_btn">Continue</button>
          </div>

  )
}

export default page